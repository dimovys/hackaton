﻿using System;
using Microsoft.AspNetCore.Identity;

namespace AwaraIt.Hackathon.Identity
{
	public class HackathonUser: IdentityUser<string>
	{

	}
}

